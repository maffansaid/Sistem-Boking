<div>
    <p>Kami beritahukan bahwa anda akan melakukan perubahan kata sandi dengan rincian akun sebagai berikut : </p>

    <table>
        <tr>
            <td>Email</td>
            <td>:</td>
            <td>{{ $data['email'] }}</td>
        </tr>
    </table>

    <p>Jika anda ingin melanjutkan perubahan kata sandi ini, gunakan kode OTP berikut : {{ $data['otp'] }}</p>
</div>
