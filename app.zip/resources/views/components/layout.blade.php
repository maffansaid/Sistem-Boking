<div>
    <x-navbar />
    {{ $slot }}
    <x-footer />
</div>
